
import { mongoDb } from './dbSimulator';
import { Complaint, ComplaintStatus, Message, User, UserRole } from '../types';
import { generateComplaintSummary } from './geminiService';

/**
 * These functions act as the "Express Controller" layer.
 * In a real app, these would be `axios.get('/api/...')`
 */

export const api = {
  // --- AUTH METHODS ---
  login: async (email: string, password?: string): Promise<User | null> => {
    // In a real system, we'd hash the password and check.
    // Here we find the user by email and password.
    const user = await mongoDb.users.findOne({ email, password });
    if (!user) return null;
    
    const { password: _, ...safeUser } = user;
    return safeUser;
  },

  register: async (name: string, email: string, password?: string): Promise<User | null> => {
    // Check if user exists
    const existing = await mongoDb.users.findOne({ email });
    if (existing) return null;

    const newUser: User & { password?: string } = {
      id: `u-${Date.now()}`,
      name,
      email,
      role: UserRole.USER,
      password: password || 'password123'
    };

    return await mongoDb.users.insertOne(newUser);
  },

  // --- COMPLAINT METHODS ---
  getComplaints: async (query?: any) => {
    return await mongoDb.complaints.find(query);
  },

  getComplaintById: async (id: string) => {
    return await mongoDb.complaints.findOne(id);
  },

  createComplaint: async (data: Omit<Complaint, 'id' | 'createdAt' | 'status' | 'messages' | 'aiSummary'>) => {
    // 1. AI Analysis (Processing like a middleware)
    const aiSummary = await generateComplaintSummary(data.description);
    
    // 2. MongoDB insertOne
    const newDoc: Complaint = {
      ...data,
      id: `RE-${Math.floor(1000 + Math.random() * 9000)}`,
      status: ComplaintStatus.PENDING,
      messages: [],
      createdAt: new Date().toISOString(),
      aiSummary
    };
    
    return await mongoDb.complaints.insertOne(newDoc);
  },

  updateComplaintStatus: async (id: string, status: ComplaintStatus, agent?: User) => {
    const update: any = { status };
    if (agent) {
      update.assignedAgentId = agent.id;
      update.assignedAgentName = agent.name;
    }
    await mongoDb.complaints.updateOne(id, update);
  },

  sendMessage: async (complaintId: string, message: Message) => {
    const complaint = await mongoDb.complaints.findOne(complaintId);
    if (complaint) {
      const updatedMessages = [...complaint.messages, message];
      await mongoDb.complaints.updateOne(complaintId, { messages: updatedMessages });
    }
  }
};
