
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { User, UserRole, Complaint, ComplaintStatus, Message } from '../types';
import { suggestResolution } from '../services/geminiService';

interface ComplaintDetailProps {
  user: User;
  complaints: Complaint[];
  agents: User[];
  onUpdateStatus: (id: string, status: ComplaintStatus, agent?: User) => void;
  onSendMessage: (id: string, text: string) => void;
}

const ComplaintDetail: React.FC<ComplaintDetailProps> = ({ user, complaints, agents, onUpdateStatus, onSendMessage }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [msg, setMsg] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState<string | null>(null);
  const [isSuggesting, setIsSuggesting] = useState(false);

  const complaint = complaints.find(c => c.id === id);

  useEffect(() => {
    if (complaint && user.role !== UserRole.USER && !aiSuggestions) {
      handleGetAiSuggestions();
    }
  }, [complaint, user.role]);

  const handleGetAiSuggestions = async () => {
    if (!complaint) return;
    setIsSuggesting(true);
    const suggestions = await suggestResolution(complaint.description);
    setAiSuggestions(suggestions);
    setIsSuggesting(false);
  };

  if (!complaint) return <div className="p-20 text-center font-bold">Record not found.</div>;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msg.trim()) return;
    onSendMessage(complaint.id, msg);
    setMsg('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col lg:flex-row gap-10">
        
        {/* Main Content Area */}
        <div className="flex-grow space-y-10">
          {/* Header Card */}
          <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-slate-100">
            <div className="flex justify-between items-start mb-8">
              <div>
                 <div className="flex items-center space-x-3 mb-4">
                    <span className="font-mono text-xs font-black text-indigo-500 bg-indigo-50 px-3 py-1 rounded-full">{complaint.id}</span>
                    <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        complaint.status === ComplaintStatus.RESOLVED ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                        {complaint.status}
                    </span>
                 </div>
                 <h1 className="text-4xl font-black text-slate-900 leading-tight mb-2">{complaint.title}</h1>
                 <p className="text-slate-400 font-medium">Submitted by <span className="text-slate-900">{complaint.userName}</span> on {new Date(complaint.createdAt).toLocaleDateString()}</p>
              </div>
              <button onClick={() => navigate('/dashboard')} className="p-3 bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-2xl transition-all">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                    <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-3">AI Case Summary</h4>
                    <p className="text-indigo-900 font-bold leading-relaxed">{complaint.aiSummary}</p>
                </div>
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Category & Date</h4>
                    <div className="text-slate-900 font-bold">{complaint.category}</div>
                    <div className="text-slate-500 text-sm mt-1">Purchased: {new Date(complaint.productDate).toLocaleDateString()}</div>
                </div>
            </div>

            <div className="space-y-4">
               <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Description</h4>
               <p className="text-slate-700 leading-relaxed font-medium whitespace-pre-wrap">{complaint.description}</p>
            </div>
          </div>

          {/* Chat Interface */}
          <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden flex flex-col h-[600px]">
            <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between">
               <h3 className="text-lg font-black text-slate-900">Communication Hub</h3>
               <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Agent Active</span>
               </div>
            </div>
            <div className="flex-grow p-8 overflow-y-auto space-y-6 bg-slate-50/50">
               {complaint.messages.map(m => (
                 <div key={m.id} className={`flex ${m.senderId === user.id ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[75%] p-5 rounded-[1.5rem] text-sm font-medium shadow-sm ${
                        m.senderId === user.id ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white text-slate-800 rounded-bl-none border border-slate-100'
                    }`}>
                        {m.text}
                        <div className={`text-[9px] mt-2 font-bold opacity-60 uppercase tracking-tighter ${m.senderId === user.id ? 'text-right' : 'text-left'}`}>
                            {m.senderName} • {new Date(m.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </div>
                    </div>
                 </div>
               ))}
            </div>
            <form onSubmit={handleSend} className="p-6 bg-white border-t border-slate-50 flex gap-4">
                <input 
                    type="text" 
                    value={msg}
                    onChange={e => setMsg(e.target.value)}
                    placeholder="Type a secure message..."
                    className="flex-grow px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-100 outline-none font-medium transition-all"
                />
                <button className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">
                    Send
                </button>
            </form>
          </div>
        </div>

        {/* Sidebar Panel */}
        <div className="lg:w-96 space-y-8">
            {/* Admin Controls */}
            {(user.role === UserRole.ADMIN || user.role === UserRole.AGENT) && (
                <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-2xl">
                    <h3 className="text-xl font-black mb-8 border-b border-white/10 pb-4 tracking-tight">Admin Console</h3>
                    
                    {user.role === UserRole.ADMIN && (
                        <div className="mb-8">
                            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Delegate Authority</label>
                            <select 
                                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl outline-none text-sm font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                                value={complaint.assignedAgentId || ''}
                                onChange={(e) => {
                                    const agent = agents.find(a => a.id === e.target.value);
                                    if (agent) onUpdateStatus(complaint.id, ComplaintStatus.ASSIGNED, agent);
                                }}
                            >
                                <option value="">Select Agent</option>
                                {agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                            </select>
                        </div>
                    )}

                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Operational Status</label>
                        <div className="grid grid-cols-1 gap-2">
                            {[ComplaintStatus.PENDING, ComplaintStatus.IN_PROGRESS, ComplaintStatus.RESOLVED].map(st => (
                                <button 
                                    key={st}
                                    onClick={() => onUpdateStatus(complaint.id, st)}
                                    className={`w-full text-left px-4 py-3 rounded-xl text-xs font-black transition-all ${
                                        complaint.status === st ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                    }`}
                                >
                                    {st.toUpperCase()}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* AI Assistant Insight */}
            {(user.role !== UserRole.USER) && (
                <div className="bg-gradient-to-br from-indigo-600 to-violet-700 text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl group-hover:scale-125 transition-transform"></div>
                    <div className="relative z-10">
                        <div className="flex items-center space-x-3 mb-6">
                            <span className="text-2xl">✨</span>
                            <h3 className="text-lg font-black tracking-tight">AI Copilot</h3>
                        </div>
                        {isSuggesting ? (
                            <div className="space-y-3">
                                <div className="h-2 bg-white/20 rounded-full animate-pulse w-full"></div>
                                <div className="h-2 bg-white/20 rounded-full animate-pulse w-5/6"></div>
                                <div className="h-2 bg-white/20 rounded-full animate-pulse w-4/6"></div>
                            </div>
                        ) : (
                            <div className="text-sm font-medium text-indigo-50 leading-relaxed whitespace-pre-line">
                                {aiSuggestions}
                            </div>
                        )}
                        <button onClick={handleGetAiSuggestions} className="mt-8 w-full py-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                            Regenerate Insight
                        </button>
                    </div>
                </div>
            )}

            <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100">
                <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-6">Assigned Handler</h3>
                <div className="flex items-center space-x-4">
                    <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-xl shadow-indigo-100">
                        {complaint.assignedAgentName?.[0] || '?'}
                    </div>
                    <div>
                        <div className="font-black text-slate-900">{complaint.assignedAgentName || 'Awaiting Handler'}</div>
                        <div className="text-xs text-indigo-500 font-bold uppercase tracking-wider">{complaint.assignedAgentId ? 'Authorized Agent' : 'System Queue'}</div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ComplaintDetail;
